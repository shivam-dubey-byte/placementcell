import React from "react";

const Settings = () => {
  return (
    <div>
      <h2>Settings</h2>
      <p>Update your account settings.</p>
    </div>
  );
};

export default Settings;