import React from "react";

const FAQs = () => {
  return (
    <div className="container mt-4">
      <h2>FAQs</h2>
      <p>Frequently Asked Questions.</p>
    </div>
  );
};

export default FAQs;
