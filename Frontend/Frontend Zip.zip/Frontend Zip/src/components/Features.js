import React from "react";

const Features = () => {
  return (
    <div className="container mt-4">
      <h2>Features</h2>
      <p>Explore the key features of our platform.</p>
    </div>
  );
};

export default Features;
