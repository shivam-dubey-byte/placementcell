import React from "react";

const FileManager = () => {
  return (
    <div>
      <h2>File Manager</h2>
      <p>Upload, download, or manage files.</p>
    </div>
  );
};

export default FileManager;