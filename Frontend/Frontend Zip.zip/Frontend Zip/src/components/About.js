import React from "react";

const About = () => {
  return (
    <div className="container mt-4">
      <h2>About Us</h2>
      <p>Learn more about our organization.</p>
    </div>
  );
};

export default About;
