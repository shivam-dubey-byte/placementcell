// src/config.js
const config = {
    BASE_URL: 'https://mujrequest.shivamrajdubey.tech/auth', // Set your base URL here 'http://localhost:3003/auth'//
  };
  
  export default config;
  